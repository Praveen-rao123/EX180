#!/usr/bin/env bash
# EX180 v4.18 - Master setup. Creates the STARTING state for every task on your
# Red Hat cloud lab so you can practice the solutions.
# Setup needs ADMIN (creates projects, StorageClass, PV).
set -uo pipefail
API="${API:-https://api.ocp4.example.com:6443}" # your lab API URL
REGISTRY="${REGISTRY:-registry.ocp4.example.com:8443}" # your lab registry
APPS="${APPS:-apps.ocp4.example.com}"           # your lab wildcard domain
here="$(cd "$(dirname "$0")" && pwd)"

# Log in as admin for setup (developer/developer is used when solving tasks)
oc login -u admin -p redhatocp "$API" --insecure-skip-tls-verify=true >/dev/null 2>&1 \
  || echo "!! could not auto-login as admin; log in manually: oc login -u admin -p redhatocp $API"

echo "### Using API=$API REGISTRY=$REGISTRY APPS=$APPS"
for s in 01-install-oc 02-secret 03-configmap 04-deploy-chatter \
         05-scale 06-limits 07-probes 08-pvc 09-pv-route 11-autoscale; do
  echo; echo "==================== $s ===================="
  REGISTRY="$REGISTRY" APPS="$APPS" bash "$here/$s.sh" || echo "!! $s reported an issue (continue)"
done
echo; echo "### Setup complete. Task 10 (must-gather) needs no setup."
