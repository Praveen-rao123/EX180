#!/usr/bin/env bash
# TASK 1 setup: make sure the target dir exists and remove any oc already there,
# so you practice downloading the matching client from the cluster.
set -uo pipefail
mkdir -p /home/opsadm/bin
rm -f /home/opsadm/bin/oc
echo "Removed /home/opsadm/bin/oc (if any). PATH should include /home/opsadm/bin."
grep -q '/home/opsadm/bin' <<<"$PATH" || echo 'TIP: export PATH=/home/opsadm/bin:$PATH'
