#!/usr/bin/env bash
# TASK 2 setup: just create the project. (You create the secret as the answer.)
set -uo pipefail
oc new-project spyrus 2>/dev/null || oc project spyrus
# Remove a pre-existing secret so the task starts clean
oc delete secret spy -n spyrus 2>/dev/null || true
echo "Project 'spyrus' ready; secret 'spy' absent."
