#!/usr/bin/env bash
# TASK 3 setup: create the source file the configmap must be built from,
# and clear any existing configmap.
set -uo pipefail
oc new-project spyrus 2>/dev/null || oc project spyrus
sudo mkdir -p /var/www/html
echo "<h1>Spyrus Blog</h1><p>EX180 practice message of the day.</p>" | sudo tee /var/www/html/index.html >/dev/null
oc delete configmap blog -n spyrus 2>/dev/null || true
echo "Created /var/www/html/index.html ; configmap 'blog' absent in spyrus."
