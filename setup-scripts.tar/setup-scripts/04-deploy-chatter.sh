#!/usr/bin/env bash
# TASK 4 setup: build & push a small stand-in 'ex180/spyrus' image that reads the
# PASSWORD env var (so adding the secret changes the response) and serves the
# configmap mounted at /messages. Requires podman login to your registry.
set -uo pipefail
REGISTRY="${REGISTRY:-registry.ocp4.example.com:8443}"
here="$(cd "$(dirname "$0")" && pwd)"
# podman login REGISTRY first with the registry creds your lab provides, e.g.:
#   podman login -u admin -p redhatocp registry.ocp4.example.com:8443
oc new-project spyrus 2>/dev/null || oc project spyrus
oc delete all -l app=chatter -n spyrus 2>/dev/null || true

echo ">> Building $REGISTRY/ex180/spyrus from ./spyrus-image"
podman build -t "$REGISTRY/ex180/spyrus" "$here/spyrus-image" || {
  echo "build failed - log in first:  podman login $REGISTRY"; exit 1; }
podman push "$REGISTRY/ex180/spyrus" || {
  echo "push failed - run:  podman login $REGISTRY"; exit 1; }
echo "Image pushed. Now deploy it as the TASK 4 answer."
