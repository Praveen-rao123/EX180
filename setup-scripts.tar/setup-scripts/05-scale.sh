#!/usr/bin/env bash
# TASK 5 setup: deploy 'scaleme' in 'lendra' at 1 replica + route.
set -uo pipefail
APPS="${APPS:-apps.ocp4.example.com}"
oc new-project lendra 2>/dev/null || oc project lendra
oc delete all -l app=scaleme -n lendra 2>/dev/null || true
oc new-app --name=scaleme --image=registry.access.redhat.com/ubi9/httpd-24 -n lendra
oc expose deployment scaleme --port=8080 -n lendra 2>/dev/null || true
oc expose svc scaleme --hostname="scaleme-lendra.$APPS" -n lendra 2>/dev/null || true
oc scale deployment scaleme --replicas=1 -n lendra
echo "Deployed scaleme (1 replica) in lendra."
