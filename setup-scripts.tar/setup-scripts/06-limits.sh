#!/usr/bin/env bash
# TASK 6 setup: deploy 'kitchens' in 'kitchen' WITHOUT resource limits + route.
set -uo pipefail
APPS="${APPS:-apps.ocp4.example.com}"
oc new-project kitchen 2>/dev/null || oc project kitchen
oc delete all -l app=kitchens -n kitchen 2>/dev/null || true
oc new-app --name=kitchens --image=registry.access.redhat.com/ubi9/httpd-24 -n kitchen
oc expose deployment kitchens --port=8080 -n kitchen 2>/dev/null || true
oc expose svc kitchens --hostname="kitchens-kitchen.$APPS" -n kitchen 2>/dev/null || true
echo "Deployed kitchens (no limits/probes) in kitchen."
