#!/usr/bin/env bash
# TASK 7 setup: kitchens is created by 06-limits.sh. Ensure it exists.
set -uo pipefail
oc project kitchen 2>/dev/null || oc new-project kitchen
oc get deployment kitchens -n kitchen >/dev/null 2>&1 || bash "$(dirname "$0")/06-limits.sh"
echo "kitchens deployment present (probes not yet set)."
