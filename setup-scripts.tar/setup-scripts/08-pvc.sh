#!/usr/bin/env bash
# TASK 8 setup: create 'restro' project and make sure a 'local-storage'
# StorageClass + a bindable PV exist so your PVC can Bind. Many labs already
# have local-storage; this is a safe fallback for self-study clusters.
set -uo pipefail
oc new-project restro 2>/dev/null || oc project restro
oc delete pvc restro-pvc -n restro 2>/dev/null || true

if ! oc get storageclass local-storage >/dev/null 2>&1; then
cat <<YAML | oc apply -f -
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: local-storage
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer
YAML
fi

# Provide a static PV (self-study only; skip if your lab auto-provisions)
cat <<YAML | oc apply -f -
apiVersion: v1
kind: PersistentVolume
metadata:
  name: ex180-local-pv
spec:
  capacity:
    storage: 24Gi
  accessModes: ["ReadWriteOnce"]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: local-storage
  hostPath:
    path: /mnt/ex180-data
YAML
echo "restro project ready; local-storage SC + 24Gi PV available."
