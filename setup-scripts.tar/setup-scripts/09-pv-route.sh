#!/usr/bin/env bash
# TASK 9 setup: deploy 'happyburgers' in 'restro' using EPHEMERAL storage
# (emptyDir at /data) and env CONFIG=/data, with NO route - so you practice
# switching it to the PVC and adding the route.
set -uo pipefail
oc new-project restro 2>/dev/null || oc project restro
oc delete all -l app=happyburgers -n restro 2>/dev/null || true
oc new-app --name=happyburgers --image=registry.access.redhat.com/ubi9/httpd-24 -n restro
oc set env deployment/happyburgers CONFIG=/data -n restro
oc set volume deployment/happyburgers --add --name=ephemeral --type=emptyDir --mount-path=/data -n restro
echo "happyburgers deployed with ephemeral /data and CONFIG=/data, no route."
