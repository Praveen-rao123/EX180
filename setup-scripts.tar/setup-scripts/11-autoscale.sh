#!/usr/bin/env bash
# TASK 11 setup: deploy 'lerna' in 'hydra' with NO HPA and NO cpu request/limit.
set -uo pipefail
oc new-project hydra 2>/dev/null || oc project hydra
oc delete hpa lerna -n hydra 2>/dev/null || true
oc delete all -l app=lerna -n hydra 2>/dev/null || true
oc new-app --name=lerna --image=registry.access.redhat.com/ubi9/httpd-24 -n hydra
echo "Deployed lerna (no resources, no HPA) in hydra."
