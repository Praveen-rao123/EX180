<?php
echo "<h1>Chatter (spyrus)</h1>";
$pw = getenv('PASSWORD');
if ($pw) {
    echo "<p style='color:green'>Authenticated: secret present, response is now privileged.</p>";
} else {
    echo "<p style='color:gray'>No secret present: public response.</p>";
}
echo "<h2>Messages (/messages):</h2><pre>";
foreach (glob('/messages/*') as $f) {
    echo htmlspecialchars(file_get_contents($f));
}
echo "</pre>";
?>
